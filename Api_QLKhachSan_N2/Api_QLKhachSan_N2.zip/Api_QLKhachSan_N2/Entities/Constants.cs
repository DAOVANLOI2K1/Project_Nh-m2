﻿namespace Api_QLKhachSan_N2.Entities
{
    public class Constants
    {
        public const int JWT_TOKEN_VALIDITY_MINS = 30;
        public const string JWT_SECURITY_KEY = "CODING_DROPLETS_12345";
    }
}
