﻿namespace Api_QLKhachSan_N2.Entities
{
    public class CustomerResponse
    {
        public string? MaKH { get; set; }
        public string? HoTen { get; set; }
        public string DiaChi { get; set; }
        public string? SDT { get; set; }
    }
}
